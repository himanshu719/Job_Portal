package com.pkg.falcon;
import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/greet") // Use the @WebServlet annotation to define the servlet mapping
public class GreetingServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String name = request.getParameter("name");
        String greeting = "Hello, " + name + "!";
        request.setAttribute("greeting", greeting);
        request.getRequestDispatcher("/greet.jsp").forward(request, response);
    }
}

